
import UIKit

class ThirdViewController: SecondViewController {

    @IBAction override func doDismiss(sender:AnyObject?) {
        super.doDismiss(sender)
    }

}
