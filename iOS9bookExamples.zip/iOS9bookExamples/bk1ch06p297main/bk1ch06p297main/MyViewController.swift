

import UIKit
import Coolness

class MyViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let d = Dog()
        d.bark()
    }

}
