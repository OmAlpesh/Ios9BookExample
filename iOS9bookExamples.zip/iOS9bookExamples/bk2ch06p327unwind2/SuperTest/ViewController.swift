

import UIKit

class ViewController : UIViewController {
    
    @IBOutlet var lab : UILabel!
    
    override var description : String {
        get {
            if self.lab != nil {
                return "View Controller \(self.lab.text!)"
            }
            else {
                return super.description
            }
        }
    }
    
    @IBAction func doUnwind(sender:UIStoryboardSegue) {
        
    }
    
    override func allowedChildViewControllersForUnwindingFromSource(source: UIStoryboardUnwindSegueSource) -> [UIViewController] {
        let result = super.allowedChildViewControllersForUnwindingFromSource(source)
        print("\(self) \(#function) \(result)")
        return result
    }
    
    override func unwindForSegue(unwindSegue: UIStoryboardSegue, towardsViewController subsequentVC: UIViewController) {
        print("\(self) \(#function) \(subsequentVC)")
        super.unwindForSegue(unwindSegue, towardsViewController: subsequentVC)
    }
    
    override func canPerformUnwindSegueAction(action: Selector, fromViewController: UIViewController, withSender sender: AnyObject) -> Bool {
        // let result = super.canPerformUnwindSegueAction(action, fromViewController: fromViewController, withSender: sender)
        let result = self.description == "View Controller 1"
        print("\(self) \(#function) \(result)")
        return result
    }
    
    override func dismissViewControllerAnimated(flag: Bool, completion: (() -> Void)?) {
        print("\(self) \(#function)")
        super.dismissViewControllerAnimated(flag, completion: completion)
    }
    
    override func shouldPerformSegueWithIdentifier(identifier: String, sender: AnyObject?) -> Bool {
        let result = super.shouldPerformSegueWithIdentifier(identifier, sender: sender)
        if identifier == "unwind" {
            print("\(self) \(#function) \(result)")
        }
        return result
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "unwind" {
            print("\(self) \(#function)")
        }
    }

    
}