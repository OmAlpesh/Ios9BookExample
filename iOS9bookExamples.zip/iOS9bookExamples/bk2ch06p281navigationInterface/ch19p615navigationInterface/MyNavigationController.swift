

import UIKit

class MyNavigationController: UINavigationController {

//    override func preferredStatusBarStyle() -> UIStatusBarStyle {
//        return .LightContent
//    }
    
//    override func childViewControllerForStatusBarStyle() -> UIViewController? {
//        let vc = super.childViewControllerForStatusBarStyle()
//        return self.topViewController
//    }

}
