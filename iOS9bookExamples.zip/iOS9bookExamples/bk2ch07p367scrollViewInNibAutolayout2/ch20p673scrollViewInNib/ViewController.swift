
import UIKit

class ViewController : UIViewController {
    
    // the content view in the nib is sized by its own width and height constraints
    
}
