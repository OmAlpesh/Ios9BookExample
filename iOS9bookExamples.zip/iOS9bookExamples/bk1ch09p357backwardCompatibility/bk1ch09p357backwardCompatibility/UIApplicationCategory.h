
@import UIKit;

@interface UIApplication (MyCategory)

+ (BOOL) safeToUseSettingsString;

@end
