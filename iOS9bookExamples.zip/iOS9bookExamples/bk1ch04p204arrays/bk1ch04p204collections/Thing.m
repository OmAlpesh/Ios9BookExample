

#import "Thing.h"

@implementation Pep

- (NSArray*) boys {
    return @[@"Manny", @"Moe", @"Jack"];
}
- (NSArray*) boysGood {
    return @[@"Manny", @"Moe", @"Jack"];
}


@end
