

import UIKit

class ViewController2: UIViewController {

    @IBAction func doDismiss(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }

    
}
