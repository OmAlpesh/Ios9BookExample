
import UIKit

class ViewController : UIViewController {
    
    // the content view in the nib is sized internally
    // by views with width and height constraints
    
}
